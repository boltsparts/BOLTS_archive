from os.path import join, exists, dirname
from os import listdir
from bolttools import blt_parser
from bolttools import freecad
from PyQt4 import QtCore
import runpy

from freecad.gui.freecad_bolts import BoltsWidget, getMainWindow

rootpath =  dirname(__file__)

#import repo
repo = blt_parser.BOLTSRepository(rootpath)

#collect bases
#TODO: read base files instead of this fragile heuristic
bases = {}
for coll in repo.collections:
	basepath = join(rootpath,"freecad","base",coll.id,"%s.py" % coll.id)
	if not exists(basepath):
		continue
	mod = runpy.run_path(basepath)
	bases.update(mod["bases"])

mw = getMainWindow()

widget = BoltsWidget(repo,bases)

mw.addDockWidget(QtCore.Qt.RightDockWidgetArea, widget)
