bases = {}
import hex.hex
bases.update(hex.hex.bases)

#start gui
from common.freecad_bolts import addWidget, BoltsWidget, bolts_path

from blt_parser import BOLTSRepository

repo = BOLTSRepository(bolts_path)

widget = BoltsWidget(repo,bases)
addWidget(widget)
