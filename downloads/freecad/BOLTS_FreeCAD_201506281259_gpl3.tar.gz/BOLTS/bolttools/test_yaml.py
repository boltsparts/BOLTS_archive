import unittest
import yaml
import json
from jsonschema import RefResolver, Draft4Validator, ValidationError, RefResolutionError
from os import listdir
from os.path import join, exists, abspath
from codecs import open

class TestData(unittest.TestCase):
    def test_data(self):
        schemadir = "yaml"
        schemapath=join(schemadir,"blt.json")
        with open(schemapath,"r","utf8") as fid:
            schema = json.loads(fid.read())
        resolver = RefResolver("file://%s/" % abspath(schemadir),schema)
        validator = Draft4Validator(schema,resolver=resolver)
        path = ".."
        for filename in listdir(join(path,"data")):
            if not filename.endswith(".blt"):
                continue
            coll_path = join(path,"data",filename)
            instance = list(yaml.load_all(open(coll_path,"r","utf8")))[0]
            try:
                validator.validate(instance)
            except ValidationError as e:
                print "ValidationError"
                print filename
                print e.message
                print e.absolute_path
                self.assertTrue(False)
            except RefResolutionError as e:
                print "RefResolutionError"
                print filename
                print e.message
                self.assertTrue(False)
